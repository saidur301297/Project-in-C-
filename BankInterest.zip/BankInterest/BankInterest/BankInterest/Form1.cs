﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankInterest
{
    public partial class Form1 : Form


    {

        Double i = 0;
        Double p = 0;
        Double r = 0;
        int n = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateBotton_Click(object sender, EventArgs e)
        {
            n = int.Parse(timeTextBox.Text);
            string bank = bankComboBox.SelectedItem.ToString();
         
            switch (bank)
            {
                case "SONALI":
                    r = .08;
                    break;
                case "BRAC":
                    r = .05;
                    break;
                case "DBBL":
                    r = .07;
                    break;
                case "HSBC":
                    r = .06;
                    break;
                default:
                    break;
            }
            p = Double.Parse(balanceTextBox.Text);
            i = p * r * n;
            interestTextBox.Text = System.Convert.ToString(i);


        }
    }
}
